#!/usr/bin/env python
# coding: utf-8

# ### 求2+4+6+...+100的求和

# In[4]:


sum = 0 
for num in range(2, 101, 2):
    sum += num
print(sum)

