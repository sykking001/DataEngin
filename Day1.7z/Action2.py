#!/usr/bin/env python
# coding: utf-8

# ### 使用python统计这些人在语文，英语，数学的平均成绩，最小成绩，最大成绩，方差，标准差，然后总成绩排序，得出名次进行成绩输出
# ![image.png](attachment:image.png)

# In[14]:


import pandas as pd
'''数据输入'''
data = {'Chinese':[68, 95, 98, 90, 80],
        'Math':[65, 76, 86,88, 90],
        'English':[30, 98, 88, 77, 90]
       }
class_score = pd.DataFrame(data, index=['Zhangfei', 'Guanyu', 'Liubei', 'Dianwei', 'Xuchu'], columns=['Chinese','Math','English'])
class_score


# In[15]:


'''统计平均成绩，最小成绩，最大成绩，标准差，方差'''
print(class_score.describe())
print(class_score.var())


# In[16]:


'''总成绩排序，得出名次进行成绩输出'''
def apply_sum(x):
    return sum(x)
class_score['Sum_Score'] = class_score.apply(apply_sum,axis=1)
class_score


# In[18]:


class_score.sort_values('Sum_Score', ascending=False)

