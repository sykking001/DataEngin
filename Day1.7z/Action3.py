#!/usr/bin/env python
# coding: utf-8

# ![image.png](attachment:image.png)

# In[14]:


import pandas as pd

# 数据加载
data = pd.read_csv('./car_complain.csv')


# In[15]:


# 删除problem列，并对其进行get_dummies操作
data = data.drop('problem', axis=1).join(data.problem.str.get_dummies(',')) # 这行的写法不是很理解
data


# In[16]:


# result = data.groupby('brand')['id'].agg(['count'])
# result


# In[18]:


# 数据清洗
def apply_replace(x):
    x = x.replace('一汽-大众','一汽大众')
    return x
data['brand'] = data['brand'].apply(apply_replace)
data


# In[23]:


# 统计品牌投诉总数
result = data.groupby('brand')['id'].agg(['count'])
result.sort_values('count', ascending=False)


# In[22]:


# 统计车型投诉总数
result2 = data.groupby('car_model')['id'].agg(['count'])
result2.sort_values('count', ascending=False)


# In[77]:


# 统计哪个品牌的平均车型投诉最多
# 如何计算一个品牌下车型的个数？？？
temp = data.iloc[:,1:3]
temp
def apply_count(x):
    pass
result_temp = temp.groupby(['brand','car_model'])['car_model'].apply(apply_count)
# print(list(result_temp))
result_temp

